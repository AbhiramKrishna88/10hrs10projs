# 10hrs10projects_Quiz_Apetite
A simple js quiz app
